import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HomeFrameTopComponent } from './components/home-frame-top/home-frame-top.component';
import { CornerLeftComponent } from './components/corner-left/corner-left.component';
import { FullPieceComponent } from './components/full-piece/full-piece.component';
import { SinglePieceComponent } from './components/single-piece/single-piece.component';
import { FramePickerComponent } from './components/frame-picker/frame-picker.component';

@Component({
  selector: 'home-manager',
  standalone: true,
  imports: [
    RouterOutlet,
    HomeFrameTopComponent,
    CornerLeftComponent,
    FullPieceComponent,
    SinglePieceComponent,
    FramePickerComponent,
  ],
  template: `
    <section
      class="flex flex-col gap-1 justify-center items-center w-full h-screen"
    >
      <!--       <home-frame-top /> -->
      <!-- <corner-left /> -->
      <!-- <full-piece /> -->
      <single-piece />
      <!-- <frame-picker class="w-3/4" /> -->
    </section>
  `,
  styles: ``,
})
export class HomeManagerComponent {}
